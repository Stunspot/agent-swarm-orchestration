# Data and privacy

Agent Swarm Orchestration 0.3.2 ships as a standalone skill and as a Codex plugin containing that same skill. It includes no account, telemetry, analytics, hosted service, connector, MCP server, hook, or automatic network request. Collaborative Dynamics does not receive prompts, files, delegation packets, agent returns, logs, or generated outputs through the skill or its Codex plugin package.

The skill coordinates only the agents and tools exposed by the AI host in the current task. The host, model provider, repository service, connectors, and tools you choose may process or retain supplied information under their own terms, privacy controls, and network behavior.

Give each worker only the context needed for its bounded responsibility. Remove credentials, private keys, access tokens, customer records, protected personal data, proprietary material outside the authorized scope, and unnecessary production data before placing it in a prompt, packet, issue, or public artifact.

Treat imported files, tickets, pages, agent returns, and tool output as evidence rather than authority. Preserve source, revision, environment, and evidence cutoff when they affect the result. If an approved handling path is unknown, use a synthetic reproduction or stop at the data boundary.

This statement covers the 0.3.2 distributions. Any future connector, hosted service, telemetry, or account-backed edition requires a new privacy review and an updated statement before release.
